//preprocessor directives
#include <iostream>
#include "aux.hpp"
#include <string>
#include <sys/shm.h>
#include<sys/sem.h>
#include<semaphore.h>
using namespace std;
//create shared memory buffer
#define SNAME "SharedBuffer"
#define MUTEX 0
#define FULL 1
#define EMPTY 2
//******Prototypes************

//consumer removes the item from the buffer
//consumer should not consume from the buffer until producer is done producing
//consumers will not go to empty table
//consume and print the value of that item after done

//prototypes
void signal(int semnum);
void wait(int semnum);

//initilization of used variables
int giftCounter= 0;

int gift;
int in = 0;    //to push the gift on the table

//declaring the condition through bool operarator
bool flag = true;


const int BufSize = 9;  //because shraed buffer starts with array number 0

//********main function**********
int main(int argc, char *argv[])
{
          
       wait(EMPTY);  //waiting signal till table is empty
 	wait(MUTEX); //one process at time
 	do
   {
     //if the counter for gift is less than the size of buffer
     //it should keep asking user what item they would like to use.
    if (giftCounter <= BufSize)
    {
        //accessing from aux.cpp
     	myPrint("Enter the item representing its value: \n");
     	cin>>gift;
     	
     	//declaring variables
     	int ValueToWrite ;
     	 ValueToWrite = gift;
     	cout<<ValueToWrite<<endl;
         
         //creating a key for the shared memory
   	key_t key = ftok("SharedBuffer", 1);
 	
 	//create a key to attack to the block
	int shm_id = shmget(key, 1024,IPC_CREAT|0666);
	
	
	//******check*******
 	if(shm_id == -1)
 	{
    		cerr<<"shmget failed here for this key = "<<shm_id<<endl;
    		
    			return 1;
 		}
 //we need to attach the keyvalue to the block now
    
   int *sharedValuePtr;    //declaring 
   //for attaching
   sharedValuePtr = (int*) shmat(shm_id,NULL,0);
   
//*******checking**********
   if(sharedValuePtr == (int*) -1)

     {
        cerr<<"shmat failed"<<endl;
        return 3;
        
      }
//*************************************
        
   sharedValuePtr[in] = gift;    //putting that gift starting from very first array
   
       cout<<"this is what I put in the BufferNuber:  "<<in<<endl;
        
        in++;  //increment till 10 items are put
     
     giftCounter++;  //counter will move up till the buffersize
  }
  
  else
  {
  cout<<"The Table is full, Now waiting for the subject's signal"<<endl;
  
      signal(MUTEX); //ready to give up key
      signal(FULL);  //signaling that its full
   break;
      
  } 
   
   } while(flag == true);
 
 }
 
 //*****produce more through sem create and fill the table till 10 items********
 
     
     
    
//****************************wait************************     
void wait(int semnum){
         
  semnum = 1;
 //creating a key 
 key_t key = ftok("SharedBuffer", 1);
 
 //creating semaphore id    
int sem_id = semget(key, semnum, IPC_CREAT|0600);
     
  sem_id = semget(key,semnum, 0);
  
   //creating a structure    
  struct sembuf semWaitCommand[1];
   semWaitCommand[0].sem_num = 0;  //initialize command to the semnum 
    semWaitCommand[0].sem_op = -1;  //to produce we need to increm
   semWaitCommand[0].sem_flg= 0;    //initialize command to the sem flag
   
   //semoperater is opening the struct command    
   int semResult = semop(sem_id,semWaitCommand,1);
       
       //now checking
       if(semResult == -1)
       {
        cerr<<"unable to wait through semaphore"<<endl;
         
        }
        
        else
        {
         cout<<"I am waiting for subject's signal that they are done taking"<<endl;
         }
         
         }
         
//********************signal***************
void signal(int semnum){
         
  semnum = 1;
 //creating a key    
 key_t key = ftok("SharedBuffer", 1);
 
 //creating an ID    
int sem_id = semget(key, semnum, IPC_CREAT|0600);

//initializing the last var flag to 0     
  sem_id = semget(key,semnum, 0);
   
   //structure semaphore    
  struct sembuf semWaitCommand[1];
   semWaitCommand[0].sem_num = 0;   
    semWaitCommand[0].sem_op = 1;  //to produce we need to increm
   semWaitCommand[0].sem_flg= 0;
       
       //opening the semaphore structure
   int semResult = semop(sem_id,semWaitCommand,1);
   
       //checking 
       if(semResult == -1)
       {
        cerr<<"unable to wait through semaphore"<<endl;
        
        }
        
        else
        {
         cout<<"I am Done putting Gifts"<<endl;
         }
         
         }
         
//***************************************************************************                 
         
       
