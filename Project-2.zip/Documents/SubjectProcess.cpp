//preprocessor directives
#include <iostream>
#include "aux.hpp"
#include <string>
#include <sys/shm.h>
#include<sys/sem.h>
#include<semaphore.h>
using namespace std;
//create shared memory buffer
#define SNAME "SharedBuffer"
#define MUTEX 0
#define FULL 1
#define EMPTY 2

//******Prototypes************
void wait(int semnum);
void signal(int semnum);
//consumer removes the item from the buffer
//consumer should not consume from the buffer until producer is done producing
//consumers will not go to empty table
//consume and print the value of that item after done

const int BufferSize = 10;   //declare the shared buffer size
   
//**************MAIN FUNCTION****************
int main(int argc, char *argv[])
{
      //creating the key named sharedbuffer with number 1
      key_t key = ftok("SharedBuffer", 1);
 	
 	//assigning shared memory ID and create the shared memory key
	int shm_id = shmget(key, 1024,IPC_CREAT|0666);
	
//****************for checking***************************
	
 	if(shm_id<=0)
 	{
    		cerr<<"shmget failed here for this key = "<<shm_id<<endl;
    		
    			return 2;
 		}
 //**************************************************************
 
 //we need to attach the keyvalue to the block now
 
     int *sharedValuePtr;   
     
     int i =0;         
     //to attach the value in the next buffer
   sharedValuePtr = (int*) shmat(shm_id,NULL,0);

    int ValueToRead[10] = {i};  //initializing 10 sizeofarray to i 
     
     wait(FULL);    //fuction call
     wait(MUTEX);    // fuction call of either royal or subject have a key
     
  for( i =0; i<= 10; i++)
    {  
         //assigning the reading value to shared buffer 
    	ValueToRead[i] = sharedValuePtr[i];
    	
       cout<<"I took the gift representing this value: " <<sharedValuePtr[i]<<endl;
       //semwait here then prompt user if they want more
       
       
      }
      
      signal(MUTEX);   //function call either royal or subjects can signal at a time
       signal(EMPTY); //signal whrn table is empty
     
  	//detach all those values from buffer to make places	 
      int detach_status = shmdt(sharedValuePtr);
         if(detach_status != 0)
         {
         cerr<<"I couldnt detach the memory"<<endl;
          return 4;
          
          }
         }
        
//****************************wait************************  
//this function initializd semaphore commands
//decrease on waiting   
void wait(int semnum){
         
  semnum = 1;    //
     
 key_t key = ftok("SharedBuffer", 1);
    //assigning semaphore iD and create the key 
int sem_id = semget(key, semnum, IPC_CREAT|0600);

     //using key semaphoreget is created
    
  sem_id = semget(key,semnum, 0);
  
     //structure semaphore  
  struct sembuf semWaitCommand[1];
  
   semWaitCommand[0].sem_num = 0; //init semaphore to 0 
    
    semWaitCommand[0].sem_op = -1;  //to produce we need to decrease the item in order tomake 
                                    //it wait
     semWaitCommand[0].sem_flg= 0;   //semaphore flag declaration
     
     //semresult is opening the semaphore struct here  
   int semResult = semop(sem_id,semWaitCommand,1);
       
       if(semResult == -1)
       {
        cerr<<"unable to wait through semaphore"<<endl;
         
        }
        
        else
        {
         cout<<"I am waiting for the royals to fill the table"<<endl;
         }
         
         }
         
//********************signal***************
//this function signal when process is done taking gifts
//it agian creates a key and open the semaphore 
//It makes another process increase their products in buffer
void signal(int semnum){
         
  semnum = 1;
     
 //again declaring the key    
 key_t key = ftok("SharedBuffer", 1);
     
int sem_id = semget(key, semnum, IPC_CREAT|0600);
     
  sem_id = semget(key,semnum, 0);
  
  //creating structure     
  struct sembuf semWaitCommand[1];
   semWaitCommand[0].sem_num = 0;   
    semWaitCommand[0].sem_op = 1;  //to produce we need increment
   semWaitCommand[0].sem_flg= 0;
     
     //open the semaphore structure here  
   int semResult = semop(sem_id,semWaitCommand,1);
       
       //check if successfull
       if(semResult == -1)
       {
        cerr<<"unable to wait through semaphore"<<endl;
         
        }
        
        else
        {
         cout<<"Yay! I was able to signal"<<endl;
         }
         
         }
         
//*************************************************************************            
