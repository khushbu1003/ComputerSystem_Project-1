#include <iostream>
#include<string>
using namespace std;

void myPrint( const string &msg)
{
cout<<msg<<endl;
}
