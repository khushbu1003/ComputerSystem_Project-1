This is Readme file

******COMPILING INSTRUCTION***********
*I have created makefile like You showed us in class, I did create aux.cpp while
following your video without realizing I didnt need However I used it once. 
* I am able to create a shared memory buffer with first defining shared buffer and then 
created a key and declared it in both of the process.
./RoyalProcess to execute it.
./SubjectProcess to ececute

royal process - it will firls ask what number would you like to add
*it will go on untill you sels=ce 10 types of key.
*I have tried using semaphore function to wait and signal however 
I dont think it works fine. I think I have came to understood what I need to do next
*however it signal and waits so it works but not at right time.

Subject Process - This Process also works fine with reading all the values
that Royal process has produced.
* It also waits and signal but probably not at right time.

Both process are successful in communicating with eachother.

**When I run both process at the same time and enter the value to the table 
**then on other window i start getting same value i put in royal process from the begining.

the next step was to make producer wait for the subject signal
and make subject process wait for products to fill buffer.

another thing that i needed to was to figure out synchonization meaning when table is empty 
no subject can come and producer cant produce till the subject is done

resources i have used
gist.github.com/jaseemabid/1922623

i have used your code throughout this whole project. for semaphore I have created struct just like how you have given us in git hub and I put it in a void function with one parameter.


*****What I could Have done better*******
I think to do the signal and wait at right time i should have used mod somewhere 
in their process.
I could have created 10 different shared memory and kept track of it and then signal each and wmake them wait.
