#include <string>

void myPrint(const std::string &m);
